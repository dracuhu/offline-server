require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 10000;
const API_VERSION = process.env.GRAPH_API_VERSION || 'v27.0';
const GRAPH = `https://graph.facebook.com/${API_VERSION}`;
const TOKEN = process.env.META_PAGE_ACCESS_TOKEN;
const IG_ID = process.env.INSTAGRAM_ACCOUNT_ID;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '32kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: true, legacyHeaders: false }));

// Optional dashboard password. Set DASHBOARD_PASSWORD in Render environment variables.
app.use((req, res, next) => {
  const expected = process.env.DASHBOARD_PASSWORD;
  if (!expected || req.path === '/health') return next();
  const header = req.headers.authorization || '';
  const [scheme, encoded] = header.split(' ');
  if (scheme === 'Basic' && encoded) {
    const decoded = Buffer.from(encoded, 'base64').toString();
    const password = decoded.slice(decoded.indexOf(':') + 1);
    if (password === expected) return next();
  }
  res.set('WWW-Authenticate', 'Basic realm="Monster Mind"');
  return res.status(401).send('Dashboard password required.');
});

app.get('/health', (_req, res) => res.json({ ok: true }));

function requireConfig(res) {
  if (!TOKEN || !IG_ID || TOKEN.startsWith('replace_') || IG_ID.startsWith('replace_')) {
    res.status(503).json({ error: 'Server is not configured. Add META_PAGE_ACCESS_TOKEN and INSTAGRAM_ACCOUNT_ID in the environment.' });
    return false;
  }
  return true;
}

async function graphGet(pathname) {
  const url = new URL(`${GRAPH}/${pathname.replace(/^\//, '')}`);
  url.searchParams.set('access_token', TOKEN);
  const response = await fetch(url);
  const data = await response.json();
  if (!response.ok || data.error) throw new Error(data.error?.message || `Meta API returned HTTP ${response.status}`);
  return data;
}

async function graphPost(pathname, payload) {
  const url = new URL(`${GRAPH}/${pathname.replace(/^\//, '')}`);
  url.searchParams.set('access_token', TOKEN);
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await response.json();
  if (!response.ok || data.error) throw new Error(data.error?.message || `Meta API returned HTTP ${response.status}`);
  return data;
}

// Fetch an existing conversation by its conversation/thread ID.
app.get('/api/conversations/:threadId', async (req, res) => {
  if (!requireConfig(res)) return;
  const threadId = String(req.params.threadId || '').trim();
  if (!/^\d{5,}$/.test(threadId)) return res.status(400).json({ error: 'Enter a valid numeric Instagram conversation/thread ID.' });
  try {
    const data = await graphGet(`${encodeURIComponent(threadId)}?fields=id,updated_time,participants,messages.limit(5){id,message,created_time,from}`);
    const participants = data.participants?.data || [];
    const recipient = participants.find(p => String(p.id) !== String(IG_ID));
    if (!recipient) return res.status(404).json({ error: 'Could not identify the other participant in this thread.' });
    res.json({ id: data.id, updated_time: data.updated_time, recipient_id: recipient.id, recipient_username: recipient.username || null, participants, messages: data.messages?.data || [] });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

// Reply to a person in an existing thread. No follower scraping, cold-DM lists, or bulk blasting.
app.post('/api/send-thread', async (req, res) => {
  if (!requireConfig(res)) return;
  const threadId = String(req.body.threadId || '').trim();
  const message = String(req.body.message || '').trim();
  const replyToId = String(req.body.replyToId || '').trim();
  if (!/^\d{5,}$/.test(threadId)) return res.status(400).json({ error: 'A valid conversation/thread ID is required.' });
  if (!message || message.length > 1000) return res.status(400).json({ error: 'Message must contain 1–1000 characters.' });
  if (replyToId && !/^\d{5,}_?\w*$/.test(replyToId)) return res.status(400).json({ error: 'Invalid reply-to message ID.' });
  try {
    const conversation = await graphGet(`${encodeURIComponent(threadId)}?fields=id,updated_time,participants`);
    const participants = conversation.participants?.data || [];
    const recipient = participants.find(p => String(p.id) !== String(IG_ID));
    if (!recipient) return res.status(404).json({ error: 'The thread does not contain a recipient other than your Instagram account.' });

    const payload = { recipient: { id: recipient.id }, message: { text: message } };
    if (replyToId) payload.reply_to = { mid: replyToId };
    const result = await graphPost(`${encodeURIComponent(IG_ID)}/messages`, payload);
    res.json({ ok: true, recipient: recipient.username || recipient.id, message_id: result.message_id || null, recipient_id: result.recipient_id || recipient.id });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.listen(PORT, '0.0.0.0', () => console.log(`Monster Mind listening on ${PORT}`));
