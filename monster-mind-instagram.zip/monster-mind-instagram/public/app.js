const $ = id => document.getElementById(id);
let loadedThread = null, sent = 0, failed = 0, started = Date.now();
function activity(message){ $('activity').textContent = message; }
function result(message, ok=false){ $('result').textContent = message; $('result').className = ok ? 'ok' : 'err'; }
function stats(){ $('sent').textContent=$('sent2').textContent=sent; $('success').textContent=$('success2').textContent=sent; $('failed').textContent=failed; }
function elapsed(){const s=Math.floor((Date.now()-started)/1000);$('clock').textContent=[Math.floor(s/3600),Math.floor(s%3600/60),s%60].map(n=>String(n).padStart(2,'0')).join(':');}
setInterval(elapsed,1000);
$('message').addEventListener('input',()=> $('count').textContent=`${$('message').value.length} / 1000`);
$('load').addEventListener('click', async()=>{
 const id=$('threadId').value.trim(); if(!id){result('Enter a conversation/thread ID.');return;}
 $('load').disabled=true; activity('Looking up conversation…'); result('');
 try{
  const r=await fetch(`/api/conversations/${encodeURIComponent(id)}`); const d=await r.json(); if(!r.ok) throw new Error(d.error||'Unable to load thread');
  loadedThread=d; $('threadInfo').innerHTML=`<div class="threadmeta"><span>Thread: <b>${escapeHtml(d.id)}</b></span><span>Recipient: <b>${escapeHtml(d.recipient_username ? '@'+d.recipient_username : d.recipient_id)}</b></span></div><p>Last activity: ${escapeHtml(d.updated_time||'Not provided')}</p>`;
  $('send').disabled=false; activity(`Loaded thread ${d.id}. Ready for a reply.`); result('Thread loaded successfully.',true);
 }catch(e){loadedThread=null;$('send').disabled=true;$('threadInfo').innerHTML='<div class="empty">Thread could not be loaded.</div>';activity(e.message);result(e.message);}
 finally{$('load').disabled=false;}
});
$('send').addEventListener('click',async()=>{
 const message=$('message').value.trim(); if(!loadedThread||!message){result('Load a thread and enter a message first.');return;}
 if(!confirm(`Send this reply to ${loadedThread.recipient_username?'@'+loadedThread.recipient_username:loadedThread.recipient_id}?`))return;
 $('send').disabled=true;activity('Sending reply through Meta…');result('');
 try{
  const r=await fetch('/api/send-thread',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({threadId:loadedThread.id,message,replyToId:$('replyToId').value.trim()})});
  const d=await r.json();if(!r.ok)throw new Error(d.error||'Send failed');
  sent++;stats();$('last').textContent=new Date().toLocaleTimeString();activity(`Message sent to ${d.recipient}. Message ID: ${d.message_id||'accepted by Meta'}`);result('Message sent successfully.',true);$('message').value='';$('count').textContent='0 / 1000';
 }catch(e){failed++;stats();activity(e.message);result(e.message);}
 finally{$('send').disabled=false;}
});
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
